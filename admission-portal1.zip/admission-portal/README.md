# Admission Inquiry Portal (PHP + MySQL on XAMPP)

A minimal admission inquiry form with an admin dashboard to view, filter, update status, and export inquiries to CSV.

## Features
- Public inquiry form (name, email, phone, program, intake, source, message)
- Server-side validation and CSRF token
- MySQL storage with prepared statements
- Admin login (hardcoded credentials in `config.php` – change them!)
- Admin dashboard with search and status update (new/contacted/closed)
- CSV export with current filters

## Requirements
- Windows + XAMPP (Apache + MySQL)
- PHP 8+ recommended

## Installation (XAMPP)
1. Stop Apache/MySQL in XAMPP if running.
2. Copy this folder `admission-portal` into `C:\xampp\htdocs\`.
3. Start Apache and MySQL in XAMPP.
4. Create database and tables:
   - Open `http://localhost/phpmyadmin/`.
   - Import `schema.sql` (or paste its content in SQL tab) to create `admission_portal` DB and `inquiries` table.
5. Configure credentials in `config.php` if needed (defaults for XAMPP: user `root`, empty password).
6. Visit the site:
   - Public form: `http://localhost/admission-portal/`
   - Admin login: `http://localhost/admission-portal/admin/login.php`

## Admin Credentials
- Username: `admin`
- Password: `admin123`

Change these in `config.php` before going live.

## Notes
- If you want to place the project in a subfolder with a different name, just match the URL accordingly.
- For production, store admin credentials in environment variables and use HTTPS.
- Backups: export data from Admin > Export CSV or via phpMyAdmin.
