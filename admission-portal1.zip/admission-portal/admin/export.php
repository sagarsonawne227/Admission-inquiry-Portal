<?php
require_once __DIR__ . '/../init.php';
require_once __DIR__ . '/protect.php';

$search = trim($_GET['q'] ?? '');
$statusFilter = trim($_GET['status'] ?? '');

$sql = 'SELECT * FROM inquiries';
$where = [];
$params = [];
$types = '';
if ($search !== '') {
    $where[] = '(full_name LIKE CONCAT("%", ?, "%") OR email LIKE CONCAT("%", ?, "%") OR phone LIKE CONCAT("%", ?, "%"))';
    $params[] = $search; $params[] = $search; $params[] = $search;
    $types .= 'sss';
}
if (in_array($statusFilter, ['new','contacted','closed'])) {
    $where[] = 'status = ?';
    $params[] = $statusFilter;
    $types .= 's';
}
if ($where) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= ' ORDER BY created_at DESC';

$stmt = $mysqli->prepare($sql);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$res = $stmt->get_result();

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="inquiries.csv"');

$out = fopen('php://output', 'w');
fputcsv($out, ['ID','Created At','Full Name','Email','Phone','Program','Intake','Source','Message','Status']);
while ($row = $res->fetch_assoc()) {
    fputcsv($out, [
        $row['id'],
        $row['created_at'],
        $row['full_name'],
        $row['email'],
        $row['phone'],
        $row['program'],
        $row['intake'],
        $row['source'],
        $row['message'],
        $row['status'],
    ]);
}
fclose($out);
exit;
