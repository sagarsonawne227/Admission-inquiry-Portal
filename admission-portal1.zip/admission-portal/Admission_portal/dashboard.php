<?php
require_once __DIR__ . '/init.php';
require_once __DIR__ . '/protect.php';

// Handle status update
if (($_SERVER['REQUEST_METHOD'] === 'POST') && isset($_POST['id'], $_POST['status'])) {
    $id = (int)$_POST['id'];
    $status = in_array($_POST['status'], ['new','contacted','closed']) ? $_POST['status'] : 'new';
    $stmt = $mysqli->prepare('UPDATE inquiries SET status=? WHERE id=?');
    $stmt->bind_param('si', $status, $id);
    $stmt->execute();
    $stmt->close();
    header('Location: dashboard.php');
    exit;
}

$search = trim($_GET['q'] ?? '');
$statusFilter = trim($_GET['status'] ?? '');

$sql = 'SELECT * FROM inquiries';
$where = [];
$params = [];
$types = '';
if ($search !== '') {
    $where[] = '(full_name LIKE CONCAT("%", ?, "%") OR email LIKE CONCAT("%", ?, "%") OR phone LIKE CONCAT("%", ?, "%"))';
    $params[] = $search; $params[] = $search; $params[] = $search;
    $types .= 'sss';
}
if (in_array($statusFilter, ['new','contacted','closed'])) {
    $where[] = 'status = ?';
    $params[] = $statusFilter;
    $types .= 's';
}
if ($where) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= ' ORDER BY created_at DESC';

$stmt = $mysqli->prepare($sql);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$rows = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootswatch@5.3.3/dist/lux/bootstrap.min.css" rel="stylesheet">
  <style>
    body.bg-hero {
      min-height: 100vh;
      background:
        linear-gradient(rgba(0,0,0,.45), rgba(0,0,0,.45)),
        url('/assets/img/campus-bg.jpg') center/cover no-repeat fixed;
    }
  </style>
</head>
<body class="bg-hero">
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container-fluid">
      <a class="navbar-brand" href="index.php">Admission Admin</a>
      <div class="d-flex gap-2">
        <a class="btn btn-outline-light btn-sm" href="index.php">Public Form</a>
        <a class="btn btn-light btn-sm" href="logout.php">Logout</a>
      </div>
    </div>
  </nav>
  <div class="container my-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h1 class="h4 m-0">Inquiries</h1>
      <a class="btn btn-success" href="export.php?q=<?php echo urlencode($search); ?>&status=<?php echo urlencode($statusFilter); ?>">Export CSV</a>
    </div>
    <form class="row g-2 mb-3" method="get">
      <div class="col-md-6">
        <input class="form-control" name="q" placeholder="Search name/email/phone" value="<?php echo htmlspecialchars($search); ?>">
      </div>
      <div class="col-md-3">
        <select class="form-select" name="status">
          <option value="">All statuses</option>
          <?php foreach (['new','contacted','closed'] as $s): ?>
            <option value="<?php echo $s; ?>" <?php if ($statusFilter===$s) echo 'selected'; ?>><?php echo ucfirst($s); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3">
        <button class="btn btn-primary w-100" type="submit">Filter</button>
      </div>
    </form>

    <div class="table-responsive">
      <table class="table table-striped table-bordered align-middle">
        <thead>
          <tr>
            <th>ID</th>
            <th>Created</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Program</th>
            <th>Intake</th>
            <th>Source</th>
            <th>Message</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!$rows): ?>
            <tr><td colspan="11" class="text-center">No inquiries found</td></tr>
          <?php endif; ?>
          <?php foreach ($rows as $r): ?>
            <tr>
              <td><?php echo (int)$r['id']; ?></td>
              <td><?php echo htmlspecialchars($r['created_at']); ?></td>
              <td><?php echo htmlspecialchars($r['full_name']); ?></td>
              <td><?php echo htmlspecialchars($r['email']); ?></td>
              <td><?php echo htmlspecialchars($r['phone']); ?></td>
              <td><?php echo htmlspecialchars($r['program']); ?></td>
              <td><?php echo htmlspecialchars($r['intake']); ?></td>
              <td><?php echo htmlspecialchars($r['source']); ?></td>
              <td style="max-width:250px; white-space:pre-wrap;"><?php echo nl2br(htmlspecialchars($r['message'])); ?></td>
              <td><?php echo ucfirst($r['status']); ?></td>
              <td>
                <form method="post" class="d-flex gap-2">
                  <input type="hidden" name="id" value="<?php echo (int)$r['id']; ?>">
                  <select name="status" class="form-select form-select-sm">
                    <?php foreach (['new','contacted','closed'] as $s): ?>
                      <option value="<?php echo $s; ?>" <?php if ($r['status']===$s) echo 'selected'; ?>><?php echo ucfirst($s); ?></option>
                    <?php endforeach; ?>
                  </select>
                  <button class="btn btn-sm btn-primary" type="submit">Update</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>
