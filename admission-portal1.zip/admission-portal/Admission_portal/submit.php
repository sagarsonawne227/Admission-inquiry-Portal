<?php
require_once __DIR__ . '/init.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    http_response_code(400);
    die('Invalid CSRF token');
}

$full_name = trim($_POST['full_name'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$program = trim($_POST['program'] ?? '');
$intake = trim($_POST['intake'] ?? '');
$source = trim($_POST['source'] ?? '');
$message = trim($_POST['message'] ?? '');

$errors = [];
if ($full_name === '') $errors[] = 'Name is required';
if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required';
if ($phone === '') $errors[] = 'Phone is required';
if ($program === '') $errors[] = 'Program is required';

if ($errors) {
    http_response_code(422);
    echo 'Validation errors: ' . implode(', ', $errors);
    echo '<br><a href="index.php">Go back</a>';
    exit;
}

$stmt = $mysqli->prepare("INSERT INTO inquiries (full_name, email, phone, program, intake, source, message) VALUES (?, ?, ?, ?, ?, ?, ?)");
if (!$stmt) {
    http_response_code(500);
    die('Failed to prepare statement');
}
$stmt->bind_param('sssssss', $full_name, $email, $phone, $program, $intake, $source, $message);
$stmt->execute();
$stmt->close();

header('Location: thankyou.php');
exit;
