-- Database schema for Admission Portal Inquiry
CREATE DATABASE IF NOT EXISTS admission_portal CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE admission_portal;

CREATE TABLE IF NOT EXISTS inquiries (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL,
  phone VARCHAR(40) NOT NULL,
  program VARCHAR(120) NOT NULL,
  intake VARCHAR(80) DEFAULT NULL,
  source VARCHAR(80) DEFAULT NULL,
  message TEXT,
  status ENUM('new','contacted','closed') NOT NULL DEFAULT 'new',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_status (status),
  KEY idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
