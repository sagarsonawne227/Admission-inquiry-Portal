<?php require_once __DIR__ . '/init.php'; ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admission Inquiry</title>
  <link href="https://cdn.jsdelivr.net/npm/bootswatch@5.3.3/dist/lux/bootstrap.min.css" rel="stylesheet">
  <style>
    body.bg-hero {
      min-height: 100vh;
      background: linear-gradient(135deg, #7edbd3 0%, #47c1b7 50%, #2ea7a0 100%) fixed;
    }
    .glass-card { background: rgba(255,255,255,0.92); border: 0; }
  </style>
</head>
<body class="bg-hero">
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
      <a class="navbar-brand" href="#">Admission Portal</a>
      <div class="ms-auto">
        <a class="btn btn-outline-light btn-sm" href="login.php">Admin</a>
      </div>
    </div>
  </nav>

  <div class="container py-5">
    <div class="row justify-content-center">
      <div class="col-12 col-lg-9 col-xl-8">
        <div class="card shadow glass-card">
          <div class="card-body">
            <h1 class="h3 mb-1">Admission Inquiry</h1>
            <p class="text-muted mb-4">Fill the form and our admissions team will reach out shortly.</p>
            <form id="inquiryForm" class="needs-validation" method="post" action="submit.php" novalidate>
              <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
              <div class="row g-3">
                <div class="col-md-6">
                  <label class="form-label" data-bs-toggle="tooltip" title="As per official documents">Full Name</label>
                  <input id="full_name" name="full_name" class="form-control" placeholder="Your full name" maxlength="100" required>
                  <div class="invalid-feedback">Please enter your full name.</div>
                </div>
                <div class="col-md-6">
                  <label class="form-label" data-bs-toggle="tooltip" title="We'll contact you here">Email</label>
                  <input id="email" type="email" name="email" class="form-control" placeholder="you@example.com" required>
                  <div class="invalid-feedback">Please provide a valid email address.</div>
                </div>
                <div class="col-md-6">
                  <label class="form-label" data-bs-toggle="tooltip" title="Digits only">Phone</label>
                  <input id="phone" name="phone" class="form-control" placeholder="10-digit number" inputmode="numeric" pattern="\\d{10}" maxlength="14" required>
                  <div class="form-text">Format: 10 digits</div>
                  <div class="invalid-feedback">Please enter a 10-digit phone number.</div>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Program Interested</label>
                  <input id="program" name="program" class="form-control" placeholder="e.g., BSc CS, MBA" maxlength="100" required>
                  <div class="invalid-feedback">Please specify a program.</div>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Preferred Intake/Semester</label>
                  <input id="intake" name="intake" class="form-control" placeholder="e.g., Jan 2026" maxlength="50">
                </div>
                <div class="col-md-6">
                  <label class="form-label">How did you hear about us?</label>
                  <select name="source" class="form-select">
                    <option value="">Select</option>
                    <option>Website</option>
                    <option>Social Media</option>
                    <option>Friend/Family</option>
                    <option>Advertisement</option>
                    <option>Other</option>
                  </select>
                </div>
                <div class="col-12">
                  <label class="form-label">Message</label>
                  <textarea id="message" name="message" class="form-control" rows="4" placeholder="Tell us more..." maxlength="500"></textarea>
                  <div class="d-flex justify-content-between">
                    <small class="text-muted">Optional</small>
                    <small class="text-muted"><span id="msgCount">0</span>/500</small>
                  </div>
                </div>
              </div>
              <div class="mt-4 d-flex gap-2 justify-content-end">
                <button id="submitBtn" class="btn btn-primary px-4" type="submit">
                  <span class="btn-text">Submit Inquiry</span>
                  <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div aria-live="polite" aria-atomic="true" class="position-relative">
    <div id="toastContainer" class="toast-container position-fixed top-0 end-0 p-3" style="z-index: 1080;"></div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    (function() {
      const form = document.getElementById('inquiryForm');
      const phone = document.getElementById('phone');
      const message = document.getElementById('message');
      const msgCount = document.getElementById('msgCount');
      const submitBtn = document.getElementById('submitBtn');
      const spinner = submitBtn.querySelector('.spinner-border');
      const btnText = submitBtn.querySelector('.btn-text');

      // Enable tooltips
      const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
      tooltipTriggerList.forEach(function (tooltipTriggerEl) {
        new bootstrap.Tooltip(tooltipTriggerEl);
      });

      // Phone masking: keep digits, format as XXX-XXX-XXXX (visual only)
      phone.addEventListener('input', function() {
        const digits = this.value.replace(/\D/g, '').slice(0, 10);
        const parts = [];
        if (digits.length > 0) parts.push(digits.substring(0, Math.min(3, digits.length)));
        if (digits.length >= 4) parts.push(digits.substring(3, Math.min(6, digits.length)));
        if (digits.length >= 7) parts.push(digits.substring(6, 10));
        this.value = parts.join('-');
        // validity based on 10 digits
        this.setCustomValidity(digits.length === 10 ? '' : 'Please enter a 10-digit phone number');
      });

      // Message live counter
      const updateCount = () => {
        msgCount.textContent = message.value.length;
      };
      message.addEventListener('input', updateCount);
      updateCount();

      // Form validation + submit loading state
      form.addEventListener('submit', function(event) {
        if (!form.checkValidity()) {
          event.preventDefault();
          event.stopPropagation();
          showToast('Please fix the errors highlighted in the form.');
        } else {
          // start loading state
          submitBtn.disabled = true;
          spinner.classList.remove('d-none');
          btnText.textContent = 'Submitting...';
        }
        form.classList.add('was-validated');
      }, false);

      function showToast(message) {
        const container = document.getElementById('toastContainer');
        const toastEl = document.createElement('div');
        toastEl.className = 'toast align-items-center text-bg-danger border-0';
        toastEl.setAttribute('role', 'alert');
        toastEl.setAttribute('aria-live', 'assertive');
        toastEl.setAttribute('aria-atomic', 'true');
        toastEl.innerHTML = `
          <div class="d-flex">
            <div class="toast-body">${message}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
          </div>`;
        container.appendChild(toastEl);
        const toast = new bootstrap.Toast(toastEl, { delay: 3000 });
        toast.show();
        toastEl.addEventListener('hidden.bs.toast', () => toastEl.remove());
      }
    })();
  </script>
</body>
</html>
