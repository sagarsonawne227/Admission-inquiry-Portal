<?php
// Basic configuration for Admission Portal Inquiry
// NOTE: For XAMPP default MySQL, user is 'root' with empty password.
// Change ADMIN_* before deploying.

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'admission_portal');

// Admin credentials (change these!)
define('ADMIN_USER', 'admin');
define('ADMIN_PASS', 'admin123');

// Optional: timezone
date_default_timezone_set('Asia/Kolkata');
