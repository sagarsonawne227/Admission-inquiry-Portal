<?php require_once __DIR__ . '/init.php'; ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Thank You</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body.bg-hero {
      min-height: 100vh;
      background:
        linear-gradient(rgba(0,0,0,.45), rgba(0,0,0,.45)),
        url('/assets/img/campus-bg.jpg') center/cover no-repeat fixed;
    }
    .glass-card { background: rgba(255,255,255,0.92); border: 0; }
  </style>
</head>
<body class="bg-light bg-hero">
  <div class="container py-5 text-center">
    <div class="col-lg-8 mx-auto">
      <div class="card shadow-sm glass-card">
        <div class="card-body p-5">
          <h1 class="h3">Thank you!</h1>
          <p class="mt-3">Your inquiry has been submitted. Our admissions team will contact you soon.</p>
          <a class="btn btn-primary" href="index.php">Back to Home</a>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
