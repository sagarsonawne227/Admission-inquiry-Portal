<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('db.php');
include('header.php'); // remove this if you don’t have header.php
?>

<div class="container mt-4">
    <h2 class="text-center">Available (Vacant) Seats</h2>
    <hr>

    <table class="table table-bordered text-center">
        <thead class="table-light">
            <tr>
                <th>#</th>
                <th>Course Name</th>
                <th>Total Intake</th>
                <th>Filled Seats</th>
                <th>Vacant Seats</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT course_name, total_intake, filled_seats, (total_intake - filled_seats) AS vacant FROM courses";
            $result = $conn->query($sql);

            if ($result && $result->num_rows > 0) {
                $i = 1;
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                        <td>{$i}</td>
                        <td>{$row['course_name']}</td>
                        <td>{$row['total_intake']}</td>
                        <td>{$row['filled_seats']}</td>
                        <td>{$row['vacant']}</td>
                    </tr>";
                    $i++;
                }
            } else {
                echo "<tr><td colspan='5'>No data found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<?php include('footer.php'); // remove if no footer ?>
