<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('db.php');

if ($conn) {
    echo "<h3>✅ Connected successfully</h3>";
} else {
    die("<h3>❌ Connection failed</h3>");
}

$result = $conn->query("SHOW TABLES");
if (!$result) {
    die("Query failed: " . $conn->error);
}

echo "<b>Tables found:</b><br>";
while ($row = $result->fetch_row()) {
    echo $row[0] . "<br>";
}
?>
                              