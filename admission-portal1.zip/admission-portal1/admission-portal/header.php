<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admission Inquiry Portal</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    body {
      background: #f4f6f9;
      min-height: 100vh;
      margin: 0;
      padding: 0;
    }

    /* 🔝 Fixed Black Navbar */
    .navbar {
      background-color: #000 !important; /* solid black */
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      z-index: 1030;
    }

    .navbar-brand, .nav-link {
      color: #fff !important;
      font-weight: 500;
    }

    .nav-link:hover, .nav-link.active {
      text-decoration: underline;
      color: #0dcaf0 !important; /* light blue on hover/active */
    }

    .navbar-brand img {
      width: 45px;
      height: 45px;
      border-radius: 50%;
      object-fit: cover;
      margin-right: 10px;
      border: 2px solid white;
    }

    /* Space below navbar to prevent content hiding */
    main {
      padding-top: 90px;
    }
  </style>
</head>
<body>

<!-- 🔹 Navbar with Logo -->
<nav class="navbar navbar-expand-lg navbar-dark shadow">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center fw-bold" href="/admission-portal1/admission-portal/index.php">
      <!-- 👇 Add your logo here -->
      <img src="/admission-portal1/admission-portal/assets/images/college_logo.png" alt="College Logo">
      Admission Portal
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
      aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link <?php if($current_page == 'index.php') echo 'active'; ?>" 
             href="/admission-portal1/admission-portal/index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if($current_page == 'cutoff.php') echo 'active'; ?>" 
             href="/admission-portal1/admission-portal/cutoff.php">Cutoff</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if($current_page == 'login.php') echo 'active'; ?>" 
             href="/admission-portal1/admission-portal/admin/login.php">Admin Login</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Add spacing so content doesn’t hide behind navbar -->
<div style="height: 70px;"></div>
