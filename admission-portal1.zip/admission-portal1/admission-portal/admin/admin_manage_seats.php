<?php
// admin_manage_seats.php
session_start();
// simple check (adjust to your auth)
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

include('../db.php');
include('../header.php'); // adjust path if header is elsewhere

// Handle add
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $course = trim($_POST['course_name']);
    $total = (int)$_POST['total_intake'];
    $filled = (int)$_POST['filled_seats'];

    $stmt = $conn->prepare("INSERT INTO courses (course_name, total_intake, filled_seats) VALUES (?, ?, ?)");
    $stmt->bind_param("sii", $course, $total, $filled);
    $stmt->execute();
    $stmt->close();

    header('Location: admin_manage_seats.php');
    exit;
}

// Handle update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update') {
    $id = (int)$_POST['id'];
    $course = trim($_POST['course_name']);
    $total = (int)$_POST['total_intake'];
    $filled = (int)$_POST['filled_seats'];

    $stmt = $conn->prepare("UPDATE courses SET course_name = ?, total_intake = ?, filled_seats = ? WHERE id = ?");
    $stmt->bind_param("siii", $course, $total, $filled, $id);
    $stmt->execute();
    $stmt->close();

    header('Location: admin_manage_seats.php');
    exit;
}

// Handle delete (GET)
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM courses WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();

    header('Location: admin_manage_seats.php');
    exit;
}
?>

<div class="container mt-4">
    <h2>Manage Course Seats</h2>

    <!-- Add form -->
    <div class="card mb-3">
        <div class="card-body">
            <form method="post" class="row g-2">
                <input type="hidden" name="action" value="add">
                <div class="col-md-5">
                    <input name="course_name" class="form-control" placeholder="Course name" required>
                </div>
                <div class="col-md-2">
                    <input name="total_intake" type="number" min="0" class="form-control" placeholder="Total intake" required>
                </div>
                <div class="col-md-2">
                    <input name="filled_seats" type="number" min="0" class="form-control" placeholder="Filled seats" required>
                </div>
                <div class="col-md-3">
                    <button class="btn btn-success w-100" type="submit">Add Course</button>
                </div>
            </form>
        </div>
    </div>

    <!-- List -->
    <table class="table table-bordered">
        <thead class="table-light">
            <tr><th>#</th><th>Course</th><th>Total</th><th>Filled</th><th>Vacant</th><th>Actions</th></tr>
        </thead>
        <tbody>
        <?php
        $res = $conn->query("SELECT * FROM courses ORDER BY course_name");
        if ($res && $res->num_rows) {
            $i = 1;
            while ($row = $res->fetch_assoc()) {
                $vac = max(0, $row['total_intake'] - $row['filled_seats']);
                echo "<tr>
                        <td>{$i}</td>
                        <td>".htmlspecialchars($row['course_name'])."</td>
                        <td>".(int)$row['total_intake']."</td>
                        <td>".(int)$row['filled_seats']."</td>
                        <td>{$vac}</td>
                        <td>
                            <a class='btn btn-sm btn-primary' href='admin_manage_seats.php?edit={$row['id']}'>Edit</a>
                            <a class='btn btn-sm btn-danger' href='admin_manage_seats.php?delete={$row['id']}' onclick=\"return confirm('Delete?')\">Delete</a>
                        </td>
                      </tr>";
                $i++;
            }
        } else {
            echo "<tr><td colspan='6'>No courses defined</td></tr>";
        }
        ?>
        </tbody>
    </table>

    <?php
    // Edit form (if requested)
    if (isset($_GET['edit'])) {
        $eid = (int)$_GET['edit'];
        $stmt = $conn->prepare("SELECT id, course_name, total_intake, filled_seats FROM courses WHERE id = ?");
        $stmt->bind_param("i", $eid);
        $stmt->execute();
        $e_res = $stmt->get_result();
        if ($e_res && $e_res->num_rows) {
            $er = $e_res->fetch_assoc();
            ?>
            <hr>
            <h4>Edit Course</h4>
            <form method="post" class="row g-2">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="id" value="<?php echo (int)$er['id']; ?>">
                <div class="col-md-6">
                    <input name="course_name" class="form-control" value="<?php echo htmlspecialchars($er['course_name']); ?>" required>
                </div>
                <div class="col-md-2">
                    <input name="total_intake" type="number" min="0" class="form-control" value="<?php echo (int)$er['total_intake']; ?>" required>
                </div>
                <div class="col-md-2">
                    <input name="filled_seats" type="number" min="0" class="form-control" value="<?php echo (int)$er['filled_seats']; ?>" required>
                </div>
                <div class="col-md-2">
                    <button class="btn btn-primary w-100" type="submit">Update</button>
                </div>
            </form>
            <?php
        }
        $stmt->close();
    }
    ?>
</div>

<?php include('../footer.php'); ?>
