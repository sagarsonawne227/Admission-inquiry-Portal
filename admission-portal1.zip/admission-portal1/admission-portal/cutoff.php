<?php
require_once __DIR__ . '/init.php';
include __DIR__ . '/header.php';

// Get filters
$year = trim($_GET['year'] ?? '');
$program = trim($_GET['program'] ?? '');
$category = trim($_GET['category'] ?? '');
$search = trim($_GET['q'] ?? '');

$sql = "SELECT * FROM cutoffs";
$where = [];
$params = [];
$types = '';

if ($year !== '') {
    $where[] = "year = ?";
    $params[] = $year;
    $types .= 'i';
}
if ($program !== '') {
    $where[] = "program = ?";
    $params[] = $program;
    $types .= 's';
}
if ($category !== '') {
    $where[] = "category = ?";
    $params[] = $category;
    $types .= 's';
}
if ($search !== '') {
    $where[] = "(program LIKE CONCAT('%', ?, '%') OR category LIKE CONCAT('%', ?, '%') OR cutoff_score LIKE CONCAT('%', ?, '%'))";
    $params[] = $search;
    $params[] = $search;
    $params[] = $search;
    $types .= 'sss';
}
if ($where) {
    $sql .= " WHERE " . implode(" AND ", $where);
}
$sql .= " ORDER BY year DESC, program ASC, category ASC";

$stmt = $mysqli->prepare($sql);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$cutoffs = $result->fetch_all(MYSQLI_ASSOC);

// Dropdown data
$years = $mysqli->query("SELECT DISTINCT year FROM cutoffs ORDER BY year DESC")->fetch_all(MYSQLI_ASSOC);
$programs = $mysqli->query("SELECT DISTINCT program FROM cutoffs ORDER BY program ASC")->fetch_all(MYSQLI_ASSOC);
$categories = $mysqli->query("SELECT DISTINCT category FROM cutoffs ORDER BY category ASC")->fetch_all(MYSQLI_ASSOC);
?>

<div class="container py-5">
  <div class="card shadow-sm glass-card border-0">
    <div class="card-body">
      <h1 class="h4 text-center mb-4">Previous Year Cutoff</h1>

      <!-- Filter Form -->
      <form class="row g-3 mb-4" method="get">
        <div class="col-md-3">
          <select class="form-select" name="year">
            <option value="">All Years</option>
            <?php foreach ($years as $y): ?>
              <option value="<?= htmlspecialchars($y['year']) ?>" <?= $year == $y['year'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($y['year']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="col-md-3">
          <select class="form-select" name="program">
            <option value="">All Programs</option>
            <?php foreach ($programs as $p): ?>
              <option value="<?= htmlspecialchars($p['program']) ?>" <?= $program == $p['program'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($p['program']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="col-md-3">
          <select class="form-select" name="category">
            <option value="">All Categories</option>
            <?php foreach ($categories as $c): ?>
              <option value="<?= htmlspecialchars($c['category']) ?>" <?= $category == $c['category'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($c['category']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="col-md-3">
          <input type="text" class="form-control" name="q" placeholder="Search..." value="<?= htmlspecialchars($search) ?>">
        </div>

        <div class="col-md-6 d-flex gap-2">
          <button class="btn btn-primary w-50" type="submit">Filter</button>
          <a href="cutoff.php" class="btn btn-secondary w-50">Reset</a>
        </div>
      </form>

      <!-- Data Table -->
      <div class="table-responsive">
        <table class="table table-striped table-bordered align-middle">
          <thead class="table-dark">
            <tr>
              <th>Program</th>
              <th>Category</th>
              <th>Year</th>
              <th>Cutoff Score</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!$cutoffs): ?>
              <tr>
                <td colspan="4" class="text-center text-muted">No records found</td>
              </tr>
            <?php else: ?>
              <?php foreach ($cutoffs as $c): ?>
                <tr>
                  <td><?= htmlspecialchars($c['program']) ?></td>
                  <td><?= htmlspecialchars($c['category']) ?></td>
                  <td><?= htmlspecialchars($c['year']) ?></td>
                  <td><?= htmlspecialchars($c['cutoff_score']) ?></td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <div class="text-center mt-3">
        <a href="index.php" class="btn btn-outline-info">← Back to Inquiry Form</a>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/footer.php'; ?>
